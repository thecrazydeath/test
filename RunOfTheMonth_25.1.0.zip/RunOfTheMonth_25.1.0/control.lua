
script.on_init(function()
    -- Initialisierung von storage
    storage = {
        kill_count = 0,
		kill_avg = 0,
		kill_max = 0,
		kill_stats = {},
		count = true
    }
end)


script.on_event(defines.events.on_entity_died, function(event)
    if storage.count and event.entity.force and event.entity.force.name == "enemy" then
        storage.kill_count = storage.kill_count + 1
    end
end)

script.on_configuration_changed(function(data)
    -- Überprüfen, ob storage existiert
    storage = storage or {
        kill_count = 0,
		kill_avg = 0,
		kill_max = 0,
		kill_stats = {},
		count = true
    }
end)

script.on_event(defines.events.on_tick, function(event)
	if game.tick % 60 == 0 then
		storage = storage or {
			kill_count = 0,
			kill_avg = 0,
			kill_max = 0,
			kill_stats = {},
			count = true
		}
		for _, player in pairs(game.connected_players) do
			if not player.gui.screen.alien_kill_counter then
				local frame = player.gui.screen.add { type = "frame", name = "alien_kill_counter", direction = "vertical", caption = "Run of the Month" }
				frame.add { type = "label", name = "kill_count_label", caption = "Aliens killed: 0" }
				frame.add { type = "label", name = "kill_stats_label", caption = "last min: 0" }
				frame.add { type = "label", name = "kill_max_label", caption = "max: 0" }
				frame.add { type = "label", name = "playtime_label", caption = "Remaining: 00:00:00" }
			end

			local frame = player.gui.screen.alien_kill_counter
			local formatted = tostring(storage.kill_count):reverse():gsub("(%d%d%d)", "%1,"):reverse()
			if formatted:sub(1, 1) == "," then
				formatted = formatted:sub(2)
			end
			frame.kill_count_label.caption = "Aliens killed: " .. formatted
			
			table.insert(storage.kill_stats, storage.kill_count)
			local last = 0
			if (#storage.kill_stats == 60) then
				last = table.remove(storage.kill_stats, 1)
			end
			if (storage.kill_max < storage.kill_count - last) then
				storage.kill_max = storage.kill_count - last
			end
			formatted = tostring(storage.kill_count - last):reverse():gsub("(%d%d%d)", "%1,"):reverse()
			if formatted:sub(1, 1) == "," then
				formatted = formatted:sub(2)
			end
			frame.kill_stats_label.caption = "last min: " .. formatted
			
			formatted = tostring(storage.kill_max):reverse():gsub("(%d%d%d)", "%1,"):reverse()
			if formatted:sub(1, 1) == "," then
				formatted = formatted:sub(2)
			end
			frame.kill_max_label.caption = "max: " .. formatted

			
			
			local playtime = math.floor(game.tick / 60)  -- convert ticks to seconds
			-- how many ticks
			local remainings = (1728000 - game.tick) / 60
			-- local remainings = (18000 - game.tick) / 60
			if remainings > 0 then
				h = math.floor(remainings / 3600)
				m = math.floor((remainings - (h * 3600)) / 60)
				s = (remainings - (h * 3600) - (m * 60))
				frame.playtime_label.caption = "Remaining: " .. string.format("%02d:%02d:%02d", h, m, s)
			else
				storage.count = false
				frame.playtime_label.caption = "Remaining: ended!"
			end
		end
	end
end)